<?php

namespace Mpdf\Http\Exception;

class ClientException extends \Mpdf\MpdfException
{

}
